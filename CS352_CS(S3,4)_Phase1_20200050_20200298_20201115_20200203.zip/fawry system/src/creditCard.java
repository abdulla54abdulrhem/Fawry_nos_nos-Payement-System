public class creditCard {
    int id=1;
    int secretCode=1;
    creditCard(){}

}
