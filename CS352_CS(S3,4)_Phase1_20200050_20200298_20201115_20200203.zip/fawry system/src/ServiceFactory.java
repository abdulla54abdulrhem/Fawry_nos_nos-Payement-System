public abstract class ServiceFactory {
    Display display;
    int option;
    public abstract service chooseService();
}
