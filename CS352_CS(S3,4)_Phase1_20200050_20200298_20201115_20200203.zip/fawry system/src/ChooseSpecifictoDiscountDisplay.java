public class ChooseSpecifictoDiscountDisplay extends Display{
    public ChooseSpecifictoDiscountDisplay(){}
    public int displayOption(){
        System.out.println("Please enter the index of the service you want to add discount to: ");
        Database.getInstance().showServices();
        option=sc.nextInt();
        while(option<0||option>=Database.getInstance().services.size()){
            System.out.println("Error, not correct index, enter again: ");
            option=sc.nextInt();
        }
        return this.option;
    }
}
